# Radio Dewi Anjani FM 104.6 MHz

Source project Flutter untuk aplikasi Android Radio Dewi Anjani.

## Fitur yang dipertahankan
- Radio streaming: https://i.klikhost.com/8140/1
- Menu Radio, Jadwal, Profil, dan Kontak
- Tautan WhatsApp dan website
- Logo Radio Dewi Anjani pada halaman utama dan ikon aplikasi Android

## Perbaikan pemutar
Tombol pemutar berubah menjadi **Stop** ketika audio sedang diputar. Indikator berputar hanya tampil ketika aplikasi sedang menghubungkan atau buffer. Pemanggilan `player.play()` tidak di-await karena Future dari just_audio selesai setelah pemutaran berakhir; meng-await-nya dapat membuat status loading seolah tidak pernah selesai.

## Build APK melalui GitHub Actions
1. Buat repository GitHub baru.
2. Upload seluruh isi folder proyek ini ke root repository (jangan upload folder pembungkusnya).
3. Pastikan branch utama bernama `main` atau `master`.
4. Buka tab **Actions**.
5. Pilih workflow **Build Radio Dewi Anjani APK**, lalu klik **Run workflow**. Workflow juga berjalan otomatis saat ada push ke branch utama.
6. Setelah selesai, buka hasil run dan unduh artifact `radio-dewi-anjani-release-apk`.
7. Ekstrak ZIP artifact untuk memperoleh `app-release.apk`.

## Catatan
- Workflow membuat file platform Android standar menggunakan Flutter stable saat build. Source aplikasi berada di `lib/` dan konfigurasi paket di `pubspec.yaml`.
- APK harus diuji pada perangkat Android sebelum dipublikasikan.
- Pastikan endpoint streaming masih aktif dan dapat diakses.
